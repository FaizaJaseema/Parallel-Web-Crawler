package com.udacity.webcrawler;

import com.udacity.webcrawler.json.CrawlResult;
import com.udacity.webcrawler.parser.PageParser;
import com.udacity.webcrawler.parser.PageParserFactory;

import javax.inject.Inject;
import javax.inject.Provider;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.Pattern;

final class ParallelWebCrawler implements WebCrawler {

  private final Clock clock;
  private final Duration timeout;
  private final int popularWordCount;
  private final ForkJoinPool pool;
  private final int maxDepth;
  private final List<Pattern> ignoredUrls;

  @Inject
  private Provider<PageParserFactory> parserFactory;

  @Inject
  ParallelWebCrawler(
          Clock clock,
          @Timeout Duration timeout,
          @PopularWordCount int popularWordCount,
          @TargetParallelism int threadCount,
          @MaxDepth int maxDepth,
          @IgnoredUrls List<Pattern> ignoredUrls) {

    this.clock = clock;
    this.timeout = timeout;
    this.popularWordCount = popularWordCount;
    this.maxDepth = maxDepth;
    this.ignoredUrls = ignoredUrls;
    this.pool = new ForkJoinPool(Math.min(threadCount, getMaxParallelism()));
  }

  @Override
  public CrawlResult crawl(List<String> startingUrls) {

    if (startingUrls.isEmpty() || maxDepth == 0) {
      return new CrawlResult.Builder()
              .setUrlsVisited(0)
              .setWordCounts(Collections.emptyMap())
              .build();
    }

    Instant deadline = clock.instant().plus(timeout);

    Set<String> visitedUrls = ConcurrentHashMap.newKeySet();
    ConcurrentMap<String, Integer> wordCounts = new ConcurrentHashMap<>();

    List<CrawlTask> tasks = new ArrayList<>();
    for (String url : startingUrls) {
      tasks.add(new CrawlTask(url, 0, deadline, visitedUrls, wordCounts));
    }

    pool.submit(() -> tasks.forEach(ForkJoinTask::invoke)).join();

    return new CrawlResult.Builder()
            .setUrlsVisited(visitedUrls.size())
            .setWordCounts(WordCounts.sort(wordCounts, popularWordCount))
            .build();
  }

  private class CrawlTask extends RecursiveAction {

    private final String url;
    private final int depth;
    private final Instant deadline;
    private final Set<String> visitedUrls;
    private final ConcurrentMap<String, Integer> wordCounts;

    CrawlTask(String url, int depth, Instant deadline,
              Set<String> visitedUrls,
              ConcurrentMap<String, Integer> wordCounts) {
      this.url = url;
      this.depth = depth;
      this.deadline = deadline;
      this.visitedUrls = visitedUrls;
      this.wordCounts = wordCounts;
    }

    @Override
    protected void compute() {

      if (depth >= maxDepth) return;
      if (clock.instant().isAfter(deadline)) return;

      if (ignoredUrls.stream().anyMatch(p -> p.matcher(url).matches())) return;

      if (!visitedUrls.add(url)) return;

      PageParser.Result result =
              parserFactory.get().get(url).parse();

      result.getWordCounts().forEach((word, count) -> {
        if (word != null && !word.isBlank()) {
          wordCounts.merge(word.toLowerCase().trim(), count, Integer::sum);
        }
      });

      List<CrawlTask> subtasks = new ArrayList<>();
      for (String link : result.getLinks()) {
        subtasks.add(new CrawlTask(link, depth + 1, deadline, visitedUrls, wordCounts));
      }

      invokeAll(subtasks);
    }
  }

  @Override
  public int getMaxParallelism() {
    return Runtime.getRuntime().availableProcessors();
  }
}