package com.udacity.webcrawler.profiler;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.Clock;
import java.time.Duration;
import java.util.Objects;

final class ProfilingMethodInterceptor implements InvocationHandler {

    private final Object target;
    private final ProfilingState state;
    private final Clock clock;

    ProfilingMethodInterceptor(Object target, ProfilingState state, Clock clock) {
        this.target = Objects.requireNonNull(target);
        this.state = Objects.requireNonNull(state);
        this.clock = Objects.requireNonNull(clock);
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

        if (method.getDeclaringClass() == Object.class) {
            return method.invoke(target, args);
        }

        boolean isProfiled = method.isAnnotationPresent(Profiled.class);

        long start = 0;
        if (isProfiled) {
            start = clock.millis();
        }

        try {
            Object result = method.invoke(target, args);

            if (isProfiled) {
                long end = clock.millis();
                state.record(
                        target.getClass(),
                        method,
                        Duration.ofMillis(end - start)
                );
            }

            return result;

        } catch (InvocationTargetException e) {

            if (isProfiled) {
                long end = clock.millis();
                state.record(
                        target.getClass(),
                        method,
                        Duration.ofMillis(end - start)
                );
            }

            throw e.getCause();

        } catch (IllegalAccessException e) {

            if (isProfiled) {
                long end = clock.millis();
                state.record(
                        target.getClass(),
                        method,
                        Duration.ofMillis(end - start)
                );
            }

            throw new RuntimeException(e);
        }
    }
}
