package com.udacity.webcrawler.profiler;

import javax.inject.Inject;
import java.io.IOException;
import java.io.Writer;
import java.nio.file.Path;
import java.time.Clock;
import java.time.ZonedDateTime;
import java.util.Objects;
import java.lang.reflect.Method;
import com.udacity.webcrawler.profiler.Profiled;

import static java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME;

/**
 * Concrete implementation of the {@link Profiler}.
 */
final class ProfilerImpl implements Profiler {

  private final Clock clock;
  private final ProfilingState state = new ProfilingState();
  private final ZonedDateTime startTime;

  @Inject
  ProfilerImpl(Clock clock) {
    this.clock = Objects.requireNonNull(clock);
    this.startTime = ZonedDateTime.now(clock);
  }

  @Override
  public <T> T wrap(Class<T> klass, T delegate) {
    Objects.requireNonNull(klass);
    Objects.requireNonNull(delegate);

    boolean hasProfiled = false;

    for (Method m : klass.getMethods()) {
      if (m.isAnnotationPresent(Profiled.class)) {
        hasProfiled = true;
        break;
      }
    }

    if (!hasProfiled) {
      throw new IllegalArgumentException("No @Profiled methods found");
    }

    return (T) java.lang.reflect.Proxy.newProxyInstance(
            klass.getClassLoader(),
            new Class<?>[]{klass},
            new ProfilingMethodInterceptor(delegate, state, clock)
    );
  }

  @Override
  public void writeData(Path path) {
    // TODO: Write the ProfilingState data to the given file path. If a file already exists at that
    //       path, the new data should be appended to the existing file.
    try (java.io.BufferedWriter writer = java.nio.file.Files.newBufferedWriter(
            path,
            java.nio.file.StandardOpenOption.CREATE,
            java.nio.file.StandardOpenOption.APPEND)) {

      writer.write("Run at " + RFC_1123_DATE_TIME.format(startTime));
      writer.newLine();
      state.write(writer);
      writer.newLine();

    } catch (IOException e) {
      throw new RuntimeException("Failed to write profiler data", e);
    }
  }

  @Override
  public void writeData(Writer writer) throws IOException {
    writer.write("Run at " + RFC_1123_DATE_TIME.format(startTime));
    writer.write(System.lineSeparator());
    state.write(writer);
    writer.write(System.lineSeparator());
  }
}
